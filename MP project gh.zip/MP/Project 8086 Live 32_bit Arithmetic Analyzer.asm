; ================================================================
; 8086 Live 32-Bit Arithmetic Analyzer
; FINAL � TEAM VERSION  (Members 1..5)
; ================================================================

.model small
.stack 100h

.data

; =====================================================
; [COMMON DATA]
; =====================================================

; 32-bit numbers = (high:low)
num1_low    dw 0
num1_high   dw 0
num2_low    dw 0
num2_high   dw 0

; 64-bit result  res3:res2:res1:res0
res0 dw 0
res1 dw 0
res2 dw 0
res3 dw 0

last_op     db 0        ; 1=add,2=sub,3=mul,4=div
carry_flag  db 0        ; used  ADD
borrow_flag db 0        ; used  SUB

; ===== Messages =====
msg_title db 0Dh,0Ah,'=== 8086 Live 32-Bit Arithmetic Analyzer (FINAL) ===',0Dh,0Ah,'$'

msg_menu db 0Dh,0Ah
db '1) Enter two 32-bit numbers (4+4 hex each)',0Dh,0Ah
db '2) Add (full 32-bit)',0Dh,0Ah
db '3) Subtract (full 32-bit)',0Dh,0Ah
db '4) Multiply 32-bit x 32-bit (full 64-bit)',0Dh,0Ah
db '5) Divide (32-bit / 16-bit low part)',0Dh,0Ah
db '6) Analyze last operation',0Dh,0Ah
db '7) Exit',0Dh,0Ah
db 'Your choice: $'

msg_invalid db 0Dh,0Ah,'[!] Invalid choice, try again.$'

msg_in1_high db 0Dh,0Ah,'Enter NUM1 HIGH (4 hex digits): $'
msg_in1_low  db 0Dh,0Ah,'Enter NUM1 LOW  (4 hex digits): $'
msg_in2_high db 0Dh,0Ah,'Enter NUM2 HIGH (4 hex digits): $'
msg_in2_low  db 0Dh,0Ah,'Enter NUM2 LOW  (4 hex digits): $'

msg_done_input db 0Dh,0Ah,'[OK] Numbers stored.$'
msg_done_add   db 0Dh,0Ah,'[OK] ADD done.$'
msg_done_sub   db 0Dh,0Ah,'[OK] SUB done.$'
msg_done_mul   db 0Dh,0Ah,'[OK] MUL 32x32->64 done.$'
msg_done_div   db 0Dh,0Ah,'[OK] DIV done.$'

msg_noop db 0Dh,0Ah,'[!] No operation done yet.$'

msg_analysis_title db 0Dh,0Ah,'--- Analysis ---',0Dh,0Ah,'$'
msg_num1 db 'Num1 = 0x','$'
msg_num2 db 0Dh,0Ah,'Num2 = 0x','$'
msg_res32 db 0Dh,0Ah,'Res  (32-bit) = 0x','$'
msg_res64 db 0Dh,0Ah,'Res  (64-bit) = 0x','$'

msg_last_add db 0Dh,0Ah,'Last op: ADD (32-bit)$'
msg_last_sub db 0Dh,0Ah,'Last op: SUB (32-bit)$'
msg_last_mul db 0Dh,0Ah,'Last op: MUL (64-bit)$'
msg_last_div db 0Dh,0Ah,'Last op: DIV (32/16)$'

msg_carry_on  db 0Dh,0Ah,'Carry flag: 1$'
msg_carry_off db 0Dh,0Ah,'Carry flag: 0$'

msg_borrow_on  db 0Dh,0Ah,'Borrow flag: 1$'
msg_borrow_off db 0Dh,0Ah,'Borrow flag: 0$'

msg_div_zero db 0Dh,0Ah,'[!] Division by zero!$'

; =====================================================
.code

; =====================================================
; [COMMON UTILITIES]  (Shared  Member 5)
; =====================================================

newline PROC
    mov ah, 2
    mov dl, 0Dh
    int 21h
    mov dl, 0Ah
    int 21h
    ret
newline ENDP

print_str PROC            ; DX -> string
    mov ah, 9
    int 21h
    ret
print_str ENDP

; ---- -> AL (0..15) ----
read_digit PROC
rd_loop:
    mov ah, 1
    int 21h

    cmp al, '0'
    jb rd_loop
    cmp al, '9'
    jbe digit

    cmp al, 'A'
    jb chk_low
    cmp al, 'F'
    jbe upper

chk_low:
    cmp al, 'a'
    jb rd_loop
    cmp al, 'f'
    jbe lower
    jmp rd_loop

digit:
    sub al, '0'
    ret

upper:
    sub al, 'A'
    add al, 10
    ret

lower:
    sub al, 'a'
    add al, 10
    ret
read_digit ENDP

; ---- -> BX ----
read_hex4 PROC
    mov cx, 4
    mov bx, 0
rh:
    call read_digit
    mov ah, 0
    shl bx, 1
    shl bx, 1
    shl bx, 1
    shl bx, 1
    add bx, ax
    loop rh
    ret
read_hex4 ENDP

; =====================================================
; [MEMBER 5] - print_hex16 (����� 16-bit �� 4 HEX)
; =====================================================

print_hex16 PROC
    push ax
    push bx
    push cx
    push dx

    mov bx, ax
    mov cx, 4

ph:
    mov dx, bx
    and dx, 0F000h
    shr dx, 12

    cmp dl, 9
    jbe dgt
    add dl, 7
dgt:
    add dl, '0'
    mov ah, 2
    int 21h

    shl bx, 4
    loop ph

    pop dx
    pop cx
    pop bx
    pop ax
    ret
print_hex16 ENDP

; =====================================================
; [MEMBER 1] - INPUT HANDLER (get_num1 & get_num2)
; =====================================================

get_num1 PROC
    mov dx, offset msg_in1_high
    call print_str
    call read_hex4
    mov num1_high, bx

    mov dx, offset msg_in1_low
    call print_str
    call read_hex4
    mov num1_low, bx
    ret
get_num1 ENDP

get_num2 PROC
    mov dx, offset msg_in2_high
    call print_str
    call read_hex4
    mov num2_high, bx

    mov dx, offset msg_in2_low
    call print_str
    call read_hex4
    mov num2_low, bx
    ret
get_num2 ENDP

; =====================================================
; [SHARED] - CLEAR RESULT + FLAGS
; =====================================================

clr PROC
    mov res0, 0
    mov res1, 0
    mov res2, 0
    mov res3, 0
    mov carry_flag, 0
    mov borrow_flag, 0
    ret
clr ENDP

; =====================================================
; [MEMBER 2] - ADD 32-BIT (add32)  + Carry flag
; =====================================================

add32 PROC
    call clr

    ; low word
    mov ax, num1_low
    add ax, num2_low
    mov res0, ax

    ; high word + carry from low
    mov ax, num1_high
    adc ax, num2_high
    mov res1, ax

    ; set carry_flag ����� ��� CF ��� ��� ADC
    mov carry_flag, 0
    jnc add_done
    mov carry_flag, 1
add_done:
    ret
add32 ENDP

; =====================================================
; [MEMBER 3] - SUB 32-BIT (sub32)  + Borrow flag
; =====================================================

sub32 PROC
    call clr

    ; low word
    mov ax, num1_low
    sub ax, num2_low
    mov res0, ax

    ; high word - borrow from low
    mov ax, num1_high
    sbb ax, num2_high
    mov res1, ax

    ; set borrow_flag 
    mov borrow_flag, 0
    jnc sub_done
    mov borrow_flag, 1
sub_done:
    ret
sub32 ENDP

; =====================================================
; [MEMBER 4] - MUL 32�32 -> 64 � DIV 32/16
; =====================================================

; ---- MUL 32�32 -> 64 ----
; ---- MUL 32x32 -> 64 ----
mul32 PROC
    call clr

    ; P0 = L1 * L2
    mov ax, num1_low
    mul num2_low          ; DX:AX = L1 * L2
    mov res0, ax          ; low  word
    mov res1, dx          ; high word

    ; P1 = L1 * H2
    mov ax, num1_low
    mul num2_high         ; DX:AX = L1 * H2
    add res1, ax          ; add low 16
    adc res2, dx          ; add high 16 + carry
    adc res3, 0           ; <-- �� ��� carry �� ����� ���� ��� ���� ����

    ; P2 = H1 * L2
    mov ax, num1_high
    mul num2_low          ; DX:AX = H1 * L2
    add res1, ax
    adc res2, dx
    adc res3, 0           ; <-- ��� ������

    ; P3 = H1 * H2
    mov ax, num1_high
    mul num2_high         ; DX:AX = H1 * H2
    add res2, ax
    adc res3, dx

    ret
mul32 ENDP


; ---- DIV 32-bit / 16-bit (num1 / num2_low) ---- ; ---- DIV 32-bit / 16-bit (num1 / num2_low) ----
; dividend = num1_high:num1_low  (DX:AX)
; divisor  = num2_low            (BX)
; result:
;   res0 = quotient   (AX)
;   res1 = remainder  (����� ����)

div32 PROC
    ; �� ������� CLR ��� ���� ������ �� ������� ��� ������

    ; 1) ����� �� ������� ���� �� ���
    mov bx, num2_low
    cmp bx, 0
    je div_err

    ; 2) ���� ��� dividend �� DX:AX
    mov dx, num1_high
    mov ax, num1_low

    ; 3) ���� 32-bit / 16-bit
    ; DX:AX / BX  ? AX = quotient
    div bx

    ; 4) ���� ��� quotient �� res0
    mov res0, ax          ; quotient

    ; 5) ���� remainder ����:
    ;    remainder = dividend - (quotient * divisor)

    ; ���� ���� ��������� ���������
    push ax               ; ���� quotient
    push bx               ; ���� divisor

    ; BX = divisor (�� �������)
    mov bx, num2_low

    ; CX = quotient
    mov cx, res0

    ; ���� q * d  (16x16 = 32-bit �� DX:AX)
    mov ax, cx            ; AX = quotient
    mul bx                ; DX:AX = quotient * divisor

    ; ���� ������ �� �� ��� dividend ������ (num1_high:num1_low)

    ; ���� ������ ������ �� BX:CX ���� ������� �� �����
    mov bx, ax            ; tmp_low
    mov cx, dx            ; tmp_high

    ; AX = low dividend
    mov ax, num1_low
    sub ax, bx            ; low_remainder = low_div - tmp_low

    ; DX = high dividend
    mov dx, num1_high
    sbb dx, cx            ; high_remainder = high_div - tmp_high - borrow

    ; ��� �� remainder ���� ���� ��� �� divisor (< 2^16)
    ; ������� DX = 0 � AX = remainder ������
    mov res1, ax          ; remainder �� res1

    ; ����� ����������� �� ��-stack
    pop bx
    pop ax

    ret

div_err:
    mov dx, offset msg_div_zero
    call print_str

    ; ���� ������� 0 ���� ������� �� ����� ����� �����
    mov res0, 0
    mov res1, 0
    ret
div32 ENDP


; =====================================================
; [MEMBER 5] - ANALYZER 
; =====================================================

analyze PROC
    cmp last_op, 0
    jne go
    mov dx, offset msg_noop
    call print_str
    ret

go:
    mov dx, offset msg_analysis_title
    call print_str

    ; ---- Num1 ----
    mov dx, offset msg_num1
    call print_str
    mov ax, num1_high
    call print_hex16
    mov ax, num1_low
    call print_hex16

    ; ---- Num2 ----
    mov dx, offset msg_num2
    call print_str
    mov ax, num2_high
    call print_hex16
    mov ax, num2_low
    call print_hex16

    ; ---- Result ----
    cmp last_op, 3
    je show64         ; MUL -> 64-bit

    ; ADD / SUB / DIV -> 32-bit from res1:res0
    mov dx, offset msg_res32
    call print_str
    mov ax, res1      ; HIGH word
    call print_hex16
    mov ax, res0      ; LOW word
    call print_hex16
    jmp showop

show64:
    ; MUL -> 64-bit
    mov dx, offset msg_res64
    call print_str
    mov ax, res3
    call print_hex16
    mov ax, res2
    call print_hex16
    mov ax, res1
    call print_hex16
    mov ax, res0
    call print_hex16

showop:
    cmp last_op, 1
    jne s2
    mov dx, offset msg_last_add
    call print_str
    jmp flags
s2:
    cmp last_op, 2
    jne s3
    mov dx, offset msg_last_sub
    call print_str
    jmp flags
s3:
    cmp last_op, 3
    jne s4
    mov dx, offset msg_last_mul
    call print_str
    jmp flags
s4:
    mov dx, offset msg_last_div
    call print_str

flags:
    ; Carry
    cmp carry_flag, 1
    jne c0
    mov dx, offset msg_carry_on
    call print_str
    jmp bf
c0:
    mov dx, offset msg_carry_off
    call print_str

bf:
    ; Borrow
    cmp borrow_flag, 1
    jne b0
    mov dx, offset msg_borrow_on
    call print_str
    ret
b0:
    mov dx, offset msg_borrow_off
    call print_str
    ret
analyze ENDP


; =====================================================
; [MEMBER 1] - MAIN MENU & CONTROL FLOW
; =====================================================

main PROC
    mov ax, @data
    mov ds, ax

main_loop:
    mov dx, offset msg_title
    call print_str

    mov dx, offset msg_menu
    call print_str

    mov ah, 1
    int 21h
    mov bl, al
    call newline

    cmp bl, '1'
    je in1
    cmp bl, '2'
    je doA
    cmp bl, '3'
    je doS
    cmp bl, '4'
    je doM
    cmp bl, '5'
    je doD
    cmp bl, '6'
    je doN
    cmp bl, '7'
    je exitp

    mov dx, offset msg_invalid
    call print_str
    jmp main_loop

in1:
    call get_num1
    call get_num2
    mov dx, offset msg_done_input
    call print_str
    jmp main_loop

doA:
    call add32
    mov last_op, 1
    mov dx, offset msg_done_add
    call print_str
    jmp main_loop

doS:
    call sub32
    mov last_op, 2
    mov dx, offset msg_done_sub
    call print_str
    jmp main_loop

doM:
    call mul32
    mov last_op, 3
    mov dx, offset msg_done_mul
    call print_str
    jmp main_loop

doD:
    call div32
    mov last_op, 4
    mov dx, offset msg_done_div
    call print_str
    jmp main_loop

doN:
    call analyze
    jmp main_loop

exitp:
    mov ax, 4C00h
    int 21h
main ENDP

END main
